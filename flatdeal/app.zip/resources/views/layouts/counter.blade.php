<section class="counter-section section-padding">
<div class="container">
<div class="row">

<div class="col-md-3 col-sm-6 work-counter-widget text-center">
<div class="counter">
<div class="icon"><i class="lni-layers"></i></div>
<div class="counterUp">12090</div>
<p>Regular Ads</p>
</div>
</div>

<div class="col-md-3 col-sm-6 work-counter-widget text-center">
<div class="counter">
<div class="icon"><i class="lni-map"></i></div>
<div class="counterUp">350</div>
<p>Locations</p>
</div>
</div>

<div class="col-md-3 col-sm-6 work-counter-widget text-center">
<div class="counter">
<div class="icon"><i class="lni-user"></i></div>
<div class="counterUp">23453</div>
<p>Reguler Members</p>
</div>
</div>

<div class="col-md-3 col-sm-6 work-counter-widget text-center">
<div class="counter">
<div class="icon"><i class="lni-briefcase"></i></div>
<div class="counterUp">250</div>
<p>Premium Ads</p>
</div>
</div>
</div>
</div>
</section>

<!--
<section class="special-offer section-padding">
<div class="container">
<h1 class="section-title">Daily Deals</h1>
<div class="row">
<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
<a href="ads-details.html"><div class="special-product">
<img src="assets/img/gallery/img-1.jpg" alt="">
<div class="product-text">
<h3>Special Offer</h3>
<div class="offer-details">
<h5 class="price">$ 1400</h5>
<h4>Buy IphoneX</h4>
<p>with special gift</p>
</div>
<div class="icon-footer">
<a href="#"><i class="icon-arrow-right-circle"></i></a>
</div>
</div>
</div></a>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
<a href="ads-details.html"><div class="special-product">
<img src="assets/img/gallery/img-2.jpg" alt="">
<div class="product-text">
<h3>Special Offer</h3>
<div class="offer-details">
<h5 class="price">$ 850</h5>
<h4>Buy Galaxy Note 8</h4>
<p>with special gift</p>
</div>
<div class="icon-footer">
<a href="#"><i class="icon-arrow-right-circle"></i></a>
</div>
</div>
</div></a>
</div>
<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
<div class="row">
<div class="col-lg-12 col-md-6 col-sm-12">
<a href="ads-details.html"><div class="special-product mb-30">
<img class="img-fluid" src="assets/img/gallery/img-3.jpg" alt="">
<div class="product-text">
<p class="text">Colorful Outdoor <br> Mattresses That Connect to Each Other</p>
<div class="icon-footer">
<h5 class="price">$ 76</h5>
</div>
</div>
</div></a>
</div>
<div class="col-lg-12 col-md-6 col-sm-12">
<a href="ads-details.html"><div class="special-product">
<img class="img-fluid" src="assets/img/gallery/img-5.jpg" alt="">
<div class="product-text">
<p class="text">Handmade Hardwood & <br> Rope Toys from Monroe Workshop</p>
<div class="icon-footer">
<h5 class="price">$ 50</h5>
</div>
</div>
</div></a>
</div>
</div>
</div>
</div>
</div>
</section>
-->