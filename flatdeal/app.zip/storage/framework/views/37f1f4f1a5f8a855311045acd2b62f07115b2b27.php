<?php if(Session::has('user_id')): ?>
   
<?php else: ?> 
<script type="text/javascript">
    window.location = "<?php echo e(url('/')); ?>";
</script> 
<?php endif; ?>