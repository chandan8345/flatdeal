<section class="featured section-padding" id="latest">
<div class="container" >
<h1 class="section-title">Latest Ads</h1>
<div class="row">
<?php $__currentLoopData = $latestads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
<div class="featured-box">
<figure>
<div class="icon">
<i class="lni-heart"></i>
</div>
<a href="#"><img class="img-fluid" src="<?php echo e(URL::to('/')); ?>/postimages/<?php echo e($row->image); ?>.jpg" alt=""></a>
</figure>
<div class="feature-content">
<div class="tg-product">
<a href="#">Category > <?php echo e($row->category); ?></a>
</div>
<h4><a href="ads-details.html"><?php echo e($row->title); ?></a></h4>
<span>Last Updated: 5 hours ago</span>
<ul class="address">
<li>
<a href="#"><i class="lni-map-marker"></i> <?php echo e($row->area); ?></a>
</li>
<li>
<a href="#"><i class="lni-alarm-clock"></i>Expire <?php echo e($row->month); ?></a>
</li>
<li>
<a href="#"><i class="lni-user"></i> <?php echo e($row->username); ?></a>
</li>
<li>
<a href="#"><i class="lni-mobile"></i> <?php echo e($row->usermobile); ?></a>
</li>
</ul>
<div class="btn-list">
<a class="btn-price" href="#">৳ <?php echo e($row->rent); ?></a>
<a class="btn btn-common" href="/singleads?id=<?php echo e($row->id); ?>">
<i class="lni-list"></i>
View Details
</a>
</div>
</div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</section>